export class Global {

    public static BASE_API_PATH = " http://localhost:8080/AgfaCsServer/checkLoginDetails/loginValiate2?hosid=1&patid=2&styid=3&mobno=1390000&identno=310107123456781234";


    

    public static BASE_IMAGE_API_PATH = "http://www.afswebapi.com/Images/";


}
