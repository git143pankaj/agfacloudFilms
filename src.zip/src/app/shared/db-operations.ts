export enum DbOperations {

    // use enam for create / update / delete etc

    create = 1,
    update = 2,
    delete = 3,
    view = 4,
    changestatus = 5



}
